﻿using System;
using System.ComponentModel.DataAnnotations;
using RT.Core;
using ServiceStack.DataAnnotations;
using ServiceStack.OrmLite;

namespace RT.Domain.Models
{
    /// <summary>
    /// Рубрика
    /// </summary>
    public class RubricCost : IEntity
    {
        /// <summary>
        /// Ид 
        /// </summary>
        [AutoIncrement]
        [PrimaryKey]
        public int Id { get; set; }

        /// <summary>
        /// ИД рубрики
        /// </summary>
        [ForeignKey(typeof(Rubric), OnDelete = "CASCADE", OnUpdate = "CASCADE")]
        public int RubricId { get; set; }

        /// <summary>
        /// Стоимость рубрики
        /// </summary>
        [Required]
        public decimal Cost { get; set; }

        /// <summary>
        /// Комментарий
        /// </summary>
        public string Comment { get; set; }

        /// <summary>
        /// Автор
        /// </summary>
        [Required]
        public string Author { get; set; }

        /// <summary>
        /// Дата создания/модификации
        /// </summary>
        [Default(typeof(DateTime), "CURRENT_TIMESTAMP")]
        public DateTime? ModifyDate { get; set; }
    }
}