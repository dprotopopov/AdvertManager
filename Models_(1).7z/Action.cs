﻿using System;
using System.ComponentModel.DataAnnotations;
using RT.Core;
using ServiceStack.DataAnnotations;

namespace RT.Domain.Models
{
    /// <summary>
    /// Действие
    /// </summary>
    public class Action : IEntity
    {
        /// <summary>
        /// ИД действия
        /// </summary>
        [AutoIncrement]
        [PrimaryKey]
        public int Id { get; set; }

        /// <summary>
        /// Противоположное действие
        /// </summary>
        public int? AntiActionId { get; set; }

        /// <summary>
        /// Заголовок
        /// </summary>
        [Required]
        [StringLength(500)]
        public string Title { get; set; }

        /// <summary>
        /// Дата изменения
        /// </summary>
        [Default(typeof(DateTime), "CURRENT_TIMESTAMP")]
        public DateTime ModifyDate { get; set; }
    }
}