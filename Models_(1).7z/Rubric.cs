﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using RT.Core;
using ServiceStack.DataAnnotations;

namespace RT.Domain.Models
{
    /// <summary>
    /// Рубрика
    /// </summary>
    public class Rubric:IEntity
    {
        /// <summary>
        /// Ид рубрики
        /// </summary>
        [AutoIncrement]
        [PrimaryKey]
        public int Id { get; set; }

        /// <summary>
        /// ИД родительской рубрики
        /// </summary>
        public int? ParentId { get; set; }
        
        /// <summary>
        /// Заголовок рубрики
        /// </summary>
        [Required]
        [StringLength(500)]
        public string Title { get; set; }

        /// <summary>
        /// Дата создания/изменения рубрики
        /// </summary>
        [Default(typeof(DateTime), "CURRENT_TIMESTAMP")]
        public DateTime ModifyDate { get; set; }
        
        /// <summary>
        /// Уровень рубрики
        /// </summary>
        public short Level { get; set; }

        /// <summary>
        /// Наличие дочерних узлов рубрики
        /// </summary>
        public bool HasChild { get; set; }

        /// <summary>
        /// Путь ИД рубрик
        /// </summary>
        [Required]
        public string IdPath { get; set; }

        /// <summary>
        /// Дочерние узлы (вспомогательное поле)
        /// </summary>
        private ObservableCollection<Rubric> _childs;

        /// <summary>
        /// Дочерние узлы (вспомогательное поле)
        /// </summary>
        [Ignore]
        public ObservableCollection<Rubric> Childs
        {
            get {
                return _childs ??
                       (_childs =
                           HasChild
                               ? new ObservableCollection<Rubric>(new List<Rubric>()
                               {
                                   new Rubric() {Title = "Loading..", Id = 0}//заполним фековым регионом, для удобства вывода treeview
                               })
                               : new ObservableCollection<Rubric>());
            }
        }
    }
}
