﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using RT.Core;
using ServiceStack.DataAnnotations;

namespace RT.Domain.Models
{
    /// <summary>
    /// Регион
    /// </summary>
    public class Region : IEntity
    {
        /// <summary>
        /// ИД региона
        /// </summary>
        [AutoIncrement]
        [PrimaryKey]
        public int Id { get; set; }

        /// <summary>
        /// ИД родительского региона
        /// </summary>
        public int? ParentId { get; set; }

        /// <summary>
        /// Заголовок региона
        /// </summary>
        [Required]
        [StringLength(500)]
        public string Title { get; set; }

        /// <summary>
        /// Дата модификации
        /// </summary>
        [Default(typeof(DateTime), "CURRENT_TIMESTAMP")]
        public DateTime ModifyDate { get; set; }

        /// <summary>
        /// Уровень региона
        /// </summary>
        public short Level { get; set; }

        /// <summary>
        /// Наличие дочерних узлов
        /// </summary>
        public bool HasChild { get; set; }

        /// <summary>
        /// Путь ИД
        /// </summary>
        [Required]
        public string IdPath { get; set; }

        /// <summary>
        /// Дочерние узлы (вспомогательное поле)
        /// </summary>
        private ObservableCollection<Region> _childs;

        /// <summary>
        /// Дочерние узлы (вспомогательное поле)
        /// </summary>
        [Ignore]
        public ObservableCollection<Region> Childs
        {
            get {
                return _childs ??
                       (_childs =
                           HasChild
                               ? new ObservableCollection<Region>(new List<Region>()
                               {
                                   new Region() {Title = "Loading..", Id = 0} //заполним фековым регионом, для удобства вывода treeview
                               })
                               : new ObservableCollection<Region>());
            }
        }
    }
}
