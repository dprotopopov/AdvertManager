﻿using RT.Domain.Models;

namespace RT.Domain.Models
{
    public class RegionsLevel : TreeLevel<Region> 
    {
       
    }
}