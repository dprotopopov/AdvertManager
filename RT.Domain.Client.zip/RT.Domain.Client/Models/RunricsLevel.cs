﻿using RT.Domain.Models;

namespace RT.Domain.Models
{
    public class RunricsLevel : TreeLevel<Rubric> 
    {
       
    }
}
