﻿using System.ComponentModel.DataAnnotations;
using RT.Core;
using ServiceStack.DataAnnotations;
using ServiceStack.OrmLite;
using System;


namespace RT.Domain.Models
{
    /// <summary>
    /// Подписка
    /// </summary>
    public class Sub : IEntity
    {
        /// <summary>
        /// ИД сущности
        /// </summary>
        [PrimaryKey]
        public int Id { get; set; }

        /// <summary>
        /// ИД региона
        /// </summary>
        public int RegionId { get; set; }

        /// <summary>
        /// ИД рубрики
        /// </summary>
        public int RubricId { get; set; }

        /// <summary>
        /// Название действия
        /// </summary>
        public string ActionTitle { get; set; }

        /// <summary>
        /// Название региона
        /// </summary>
        public string RegionTitle { get; set; }

        /// <summary>
        /// Название рубрики
        /// </summary>
        public string RubricTitle { get; set; }

        /// <summary>
        /// ИД действия
        /// </summary>
        public int ActionId { get; set; }

        /// <summary>
        /// ИД пользователя
        /// </summary>
        [ForeignKey(typeof(User), OnDelete = "CASCADE", OnUpdate = "CASCADE")]
        public int UserId { get; set; }
        [Required]
        [StringLength(255)]
        public string Bind { get; set; }

        /// <summary>
        /// Дата создания/модификации
        /// </summary>
        [Default(typeof(DateTime), "CURRENT_TIMESTAMP")]
        public DateTime? ModifyDate { get; set; }
    }
}